import React, { useState } from 'react';
import { Contact } from '../types';
import { sounds } from '../services/soundEffects';
import { createContact } from '../services/api';

interface NewChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContactCreated: (contact: Contact) => void;
  existingContacts?: Contact[];
}

export const NewChatModal: React.FC<NewChatModalProps> = ({
  isOpen,
  onClose,
  onContactCreated,
  existingContacts = []
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'online' | 'satellite' | 'favorites'>('all');
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+1 (555) ');
  const [role, setRole] = useState('Tactical Responder');
  const [isGroup, setIsGroup] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  if (!isOpen) return null;

  // Preset nearby off-grid devices
  const nearbyDevices = [
    {
      id: 'nearby_alex',
      name: 'Alex Miller',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      subtitle: 'Nearby • 5m away',
      icon: 'bluetooth',
      tag: 'Ready',
      tagColor: 'primary'
    },
    {
      id: 'nearby_node2',
      name: 'Basecamp Node #02',
      avatar: '',
      subtitle: 'Relay available • Strong signal',
      icon: 'cell_tower',
      tag: 'Mesh link',
      tagColor: 'secondary'
    }
  ];

  // Preset default contacts if empty
  const defaultContacts: Contact[] = existingContacts.length > 0 ? existingContacts : [
    {
      id: 'c_elena',
      name: 'Elena Rostova',
      role: 'Alpine Research Lead',
      phone: '+1 (555) 0124',
      nexusId: 'NX-ELENA-SAT',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      online: true,
      lastSeen: 'Active now',
      satelliteLinked: true,
      satelliteSignal: 94,
      isGroup: false,
      unreadCount: 0,
      lastMessage: 'Tethered via Bluetooth. 3 satellites locked...',
      lastMessageTime: '10:24 AM',
      verifiedBharat: true,
      encryptionKey: '0x8F92...B314',
      about: 'Alpine expedition lead'
    },
    {
      id: 'c_marcus',
      name: 'Marcus Vance',
      role: 'Terrain Surveyor',
      phone: '+1 (555) 0188',
      nexusId: 'NX-MARCUS-5G',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      online: true,
      lastSeen: 'Last seen 2h ago',
      satelliteLinked: false,
      satelliteSignal: 45,
      isGroup: false,
      unreadCount: 0,
      lastMessage: 'Sending coordinates now. See you at waypoint 4.',
      lastMessageTime: 'Yesterday',
      verifiedBharat: true,
      encryptionKey: '0x4E71...99FA',
      about: 'Field coordinator'
    },
    {
      id: 'c_maya',
      name: 'Maya Lin',
      role: 'Remote Sensing',
      phone: '+1 (555) 0199',
      nexusId: 'NX-MAYA-ORBIT',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150',
      online: false,
      lastSeen: 'In remote area',
      satelliteLinked: true,
      satelliteSignal: 98,
      isGroup: false,
      unreadCount: 0,
      lastMessage: 'Voice note (0:14) · via satellite',
      lastMessageTime: 'Oct 24',
      verifiedBharat: true,
      encryptionKey: '0x11AB...77FC',
      about: 'Glacial research'
    }
  ];

  const filteredContacts = defaultContacts.filter((c) => {
    const matches =
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.nexusId && c.nexusId.toLowerCase().includes(searchTerm.toLowerCase()));
    if (!matches) return false;

    if (activeFilter === 'online') return c.online;
    if (activeFilter === 'satellite') return c.satelliteLinked;
    if (activeFilter === 'favorites') return c.verifiedBharat;
    return true;
  });

  const handleCreateNewContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsCreating(true);
    sounds.playSentSound();

    try {
      const newContact = await createContact({
        name: name.trim(),
        phone: phone.trim(),
        role: role.trim(),
        isGroup,
        satelliteLinked: true,
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
      });
      onContactCreated(newContact);
      onClose();
    } catch {
      // Mock create for offline resilience
      const mock: Contact = {
        id: 'contact_' + Date.now(),
        name: name.trim(),
        role: role.trim(),
        phone: phone.trim(),
        nexusId: 'NX-' + name.slice(0, 4).toUpperCase(),
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
        online: true,
        lastSeen: 'Active now',
        satelliteLinked: true,
        satelliteSignal: 90,
        isGroup,
        unreadCount: 0,
        lastMessage: 'Encrypted channel established.',
        lastMessageTime: 'Just now',
        verifiedBharat: true,
        encryptionKey: '0x99A...E2EE',
        about: 'Sovereign Nexus contact'
      };
      onContactCreated(mock);
      onClose();
    } finally {
      setIsCreating(false);
    }
  };

  const handleSelectExisting = (c: Contact) => {
    sounds.playSentSound();
    onContactCreated(c);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-surface-container-lowest/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-md min-h-screen sm:min-h-0 sm:max-h-[92vh] sm:my-6 bg-surface sm:rounded-2xl sm:border sm:border-surface-container-high shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-surface/90 backdrop-blur-xl border-b border-surface-container-high/60 pt-safe">
          <div className="h-16 px-4 flex items-center justify-between">
            <div className="flex items-center gap-space-sm">
              <button
                type="button"
                aria-label="Go Back"
                onClick={onClose}
                className="w-10 h-10 flex items-center justify-center rounded-lg text-on-surface hover:text-primary transition-colors"
              >
                <span className="material-symbols-outlined text-[22px]">arrow_back</span>
              </button>
              <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[18px]">satellite_alt</span>
              </div>
              <div className="flex flex-col ml-1">
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-[9px] text-primary tracking-widest uppercase font-bold">NEXUS</span>
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                </div>
                <h1 className="font-semibold text-sm text-on-surface leading-tight">New Message</h1>
                <span className="font-mono text-[9px] text-on-surface-variant uppercase">Select Contact</span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setShowAddForm(!showAddForm)}
                className="w-9 h-9 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface-variant hover:text-primary flex items-center justify-center transition-colors"
                title="Create New Contact"
              >
                <span className="material-symbols-outlined text-[20px]">
                  {showAddForm ? 'close' : 'person_add'}
                </span>
              </button>
            </div>
          </div>
        </header>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto no-scrollbar pb-6 flex flex-col">
          {/* Custom Create Form (Toggleable) */}
          {showAddForm ? (
            <form onSubmit={handleCreateNewContact} className="p-4 space-y-3 bg-surface-container-low border-b border-surface-container-high">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-xs text-on-surface">Add New Contact or Group</h3>
                <span className="font-mono text-[10px] text-primary">Double Ratchet 256</span>
              </div>
              <div className="grid grid-cols-2 gap-2 p-1 bg-surface-container rounded-lg">
                <button
                  type="button"
                  onClick={() => setIsGroup(false)}
                  className={`py-1.5 rounded text-xs font-semibold ${!isGroup ? 'bg-primary text-on-primary' : 'text-on-surface-variant'}`}
                >
                  Direct 1-on-1
                </button>
                <button
                  type="button"
                  onClick={() => setIsGroup(true)}
                  className={`py-1.5 rounded text-xs font-semibold ${isGroup ? 'bg-primary text-on-primary' : 'text-on-surface-variant'}`}
                >
                  Group Mesh
                </button>
              </div>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={isGroup ? 'Group Name (e.g. Siachen Recon Patrol)' : 'Full Name or Callsign'}
                className="w-full h-10 bg-surface-container rounded-lg px-3 text-xs text-on-surface placeholder:text-outline focus:outline-none border border-surface-container-high"
                required
              />
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Mobile number / Callsign"
                className="w-full h-10 bg-surface-container rounded-lg px-3 text-xs text-on-surface placeholder:text-outline focus:outline-none border border-surface-container-high"
              />
              <button
                type="submit"
                disabled={isCreating}
                className="w-full h-10 rounded-lg bg-primary text-on-primary font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95"
              >
                <span className="material-symbols-outlined text-[18px]">check</span>
                <span>{isCreating ? 'Creating Channel...' : 'Create & Open Chat'}</span>
              </button>
            </form>
          ) : (
            <>
              {/* Search Section */}
              <div className="px-4 pt-3 pb-2">
                <div className="relative flex items-center bg-surface-container rounded-xl p-1 border border-surface-container-high shadow-sm">
                  <span className="material-symbols-outlined text-on-surface-variant text-[20px] ml-2 shrink-0">
                    search
                  </span>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search name, phone, or Satellite ID..."
                    className="w-full bg-transparent px-2.5 py-1.5 text-xs text-on-surface placeholder:text-on-surface-variant outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playRadioSquelch();
                    }}
                    className="w-8 h-8 rounded-lg bg-surface-container-highest flex items-center justify-center text-primary hover:bg-primary-container hover:text-on-primary-container transition-colors shrink-0 active:scale-95"
                  >
                    <span className="material-symbols-outlined text-[18px]">qr_code_scanner</span>
                  </button>
                </div>
              </div>

              {/* Quick Action Shortcuts (2x2 Grid) */}
              <div className="px-4 py-1.5">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsGroup(true);
                      setShowAddForm(true);
                    }}
                    className="flex flex-col text-left p-3 bg-surface-container-low hover:bg-surface-container rounded-xl transition-all active:scale-[0.98] border border-surface-container-high/60"
                  >
                    <div className="w-9 h-9 rounded-lg bg-surface-container-highest flex items-center justify-center text-primary mb-2 relative">
                      <span className="material-symbols-outlined text-[20px]">group</span>
                      <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-primary text-on-primary rounded-full flex items-center justify-center text-[9px] font-bold">
                        +
                      </span>
                    </div>
                    <span className="font-semibold text-xs text-on-surface">New Group</span>
                    <span className="text-[10px] text-on-surface-variant mt-0.5 line-clamp-1">
                      Up to 100 people offline or online
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsGroup(true);
                      setShowAddForm(true);
                    }}
                    className="flex flex-col text-left p-3 bg-surface-container-low hover:bg-surface-container rounded-xl transition-all active:scale-[0.98] border border-surface-container-high/60"
                  >
                    <div className="w-9 h-9 rounded-lg bg-surface-container-highest flex items-center justify-center text-secondary mb-2">
                      <span className="material-symbols-outlined text-[20px]">podcasts</span>
                    </div>
                    <span className="font-semibold text-xs text-on-surface">New Channel</span>
                    <span className="text-[10px] text-on-surface-variant mt-0.5 line-clamp-1">
                      Broadcast updates to your team
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowAddForm(true)}
                    className="flex flex-col text-left p-3 bg-surface-container-low hover:bg-surface-container rounded-xl transition-all active:scale-[0.98] border border-surface-container-high/60"
                  >
                    <div className="w-9 h-9 rounded-lg bg-surface-container-highest flex items-center justify-center text-primary mb-2">
                      <span className="material-symbols-outlined text-[20px]">satellite_alt</span>
                    </div>
                    <span className="font-semibold text-xs text-on-surface">Add by Satellite ID</span>
                    <span className="text-[10px] text-on-surface-variant mt-0.5 line-clamp-1">
                      Connect without cellular
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => sounds.playRadioSquelch()}
                    className="flex flex-col text-left p-3 bg-surface-container-low hover:bg-surface-container rounded-xl transition-all active:scale-[0.98] border border-surface-container-high/60"
                  >
                    <div className="w-9 h-9 rounded-lg bg-surface-container-highest flex items-center justify-center text-tertiary mb-2">
                      <span className="material-symbols-outlined text-[20px]">qr_code_2</span>
                    </div>
                    <span className="font-semibold text-xs text-on-surface">Scan QR Code</span>
                    <span className="text-[10px] text-on-surface-variant mt-0.5 line-clamp-1">
                      Quick connect in person
                    </span>
                  </button>
                </div>
              </div>

              {/* Nearby Off-Grid Devices (Mesh / Bluetooth) */}
              <div className="mt-3 px-4">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
                    </span>
                    <h2 className="font-semibold text-xs text-on-surface">Nearby Off-Grid Devices</h2>
                  </div>
                  <span className="font-mono text-[9px] text-primary bg-primary/10 px-2 py-0.5 rounded-full font-semibold">
                    3 found
                  </span>
                </div>
                <p className="text-[11px] text-on-surface-variant mb-2">
                  Reachable directly through close-range radio or Bluetooth.
                </p>

                <div className="flex flex-col gap-1.5">
                  {nearbyDevices.map((dev) => (
                    <div
                      key={dev.id}
                      className="flex items-center justify-between p-2.5 bg-surface-container-low hover:bg-surface-container rounded-xl transition-all border border-surface-container-high/60"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {dev.avatar ? (
                          <div className="relative w-10 h-10 shrink-0">
                            <img className="w-10 h-10 rounded-full object-cover" src={dev.avatar} alt={dev.name} />
                            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-primary rounded-full ring-2 ring-surface-container-low" />
                          </div>
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center text-secondary shrink-0">
                            <span className="material-symbols-outlined text-[20px]">router</span>
                          </div>
                        )}
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs text-on-surface font-semibold truncate">{dev.name}</span>
                          <div className="flex items-center gap-1 text-[11px] text-on-surface-variant">
                            <span className="material-symbols-outlined text-[13px] text-primary">{dev.icon}</span>
                            <span className="truncate">{dev.subtitle}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className="text-[10px] bg-primary/15 text-primary px-2 py-0.5 rounded-full font-medium">
                          {dev.tag}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            sounds.playSentSound();
                            onContactCreated({
                              id: dev.id,
                              name: dev.name,
                              role: 'Nearby Mesh Node',
                              phone: '+1 (555) 0122',
                              nexusId: 'NX-MESH-LOCAL',
                              avatar: dev.avatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
                              online: true,
                              lastSeen: 'Active now',
                              satelliteLinked: true,
                              satelliteSignal: 96,
                              isGroup: false,
                              unreadCount: 0,
                              lastMessage: 'Direct Bluetooth link open.',
                              lastMessageTime: 'Just now',
                              verifiedBharat: true,
                              encryptionKey: '0x334...LOCAL',
                              about: 'Close-range off-grid peer'
                            });
                            onClose();
                          }}
                          className="w-8 h-8 rounded-lg bg-surface-container-highest flex items-center justify-center text-on-surface hover:text-primary transition-colors"
                        >
                          <span className="material-symbols-outlined text-[16px]">chat</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contacts Section */}
              <div className="mt-4 px-4">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="font-semibold text-xs text-on-surface">Your Contacts</h2>
                  <button
                    type="button"
                    onClick={() => setShowAddForm(true)}
                    className="text-xs text-primary hover:underline flex items-center gap-0.5"
                  >
                    <span className="material-symbols-outlined text-[15px]">person_add</span>
                    <span>Add</span>
                  </button>
                </div>

                {/* Filter Chips */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-2 no-scrollbar">
                  {(['all', 'online', 'satellite', 'favorites'] as const).map((filter) => (
                    <button
                      key={filter}
                      type="button"
                      onClick={() => setActiveFilter(filter)}
                      className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap active:scale-95 transition-all ${
                        activeFilter === filter
                          ? 'bg-primary text-on-primary'
                          : 'bg-surface-container-low text-on-surface-variant hover:text-on-surface border border-surface-container-high/60'
                      }`}
                    >
                      {filter === 'all' && `All (${filteredContacts.length})`}
                      {filter === 'online' && 'Online'}
                      {filter === 'satellite' && 'Satellite Ready'}
                      {filter === 'favorites' && 'Favorites'}
                    </button>
                  ))}
                </div>

                {/* Contact List */}
                <div className="flex flex-col gap-1.5 mt-1">
                  {filteredContacts.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => handleSelectExisting(c)}
                      className="flex items-center justify-between p-2.5 bg-surface-container-low hover:bg-surface-container rounded-xl transition-all cursor-pointer border border-surface-container-high/60"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="relative w-11 h-11 shrink-0">
                          <img className="w-11 h-11 rounded-full object-cover" src={c.avatar} alt={c.name} />
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-primary rounded-full ring-2 ring-surface-container-low" />
                        </div>
                        <div className="flex flex-col min-w-0">
                          <div className="flex items-center gap-1">
                            <span className="text-xs font-semibold text-on-surface truncate">{c.name}</span>
                            <span className="material-symbols-outlined text-[14px] text-primary shrink-0">verified</span>
                          </div>
                          <span className="text-[11px] text-on-surface-variant truncate">
                            {c.satelliteLinked ? 'Active now • Satellite link ready' : 'Active now • Internet'}
                          </span>
                        </div>
                      </div>

                      <div className="shrink-0 ml-2">
                        {c.satelliteLinked ? (
                          <span className="material-symbols-outlined text-primary text-[18px]">satellite_alt</span>
                        ) : (
                          <span className="material-symbols-outlined text-on-surface-variant text-[18px]">wifi</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
