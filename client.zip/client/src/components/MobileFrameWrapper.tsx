import React, { useState, useEffect } from 'react';
import { Wifi, Radio, Battery, Monitor, WifiOff } from 'lucide-react';
import { SatelliteModuleState } from '../types';

interface MobileFrameWrapperProps {
  isMobileFrame: boolean;
  onToggleFrame: () => void;
  satelliteState: SatelliteModuleState | null;
  children: React.ReactNode;
}

export const MobileFrameWrapper: React.FC<MobileFrameWrapperProps> = ({
  isMobileFrame,
  onToggleFrame,
  satelliteState,
  children
}) => {
  const [currentTime, setCurrentTime] = useState<string>(() => {
    const d = new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  });

  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const d = new Date();
      setCurrentTime(d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    }, 10000);

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      clearInterval(timer);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!isMobileFrame) {
    return (
      <div className="w-full h-screen bg-[#080d14] overflow-hidden flex flex-col">
        {children}
      </div>
    );
  }

  const isSat = satelliteState?.mode === 'satellite_only';
  const carrierText = isSat
    ? 'NavIC Sat'
    : !isOnline
    ? 'No Service'
    : '5G / Wi-Fi';

  return (
    <div className="w-full h-screen bg-[#04070c] flex flex-col items-center justify-center p-0 md:p-4 select-none overflow-hidden relative">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Floating Toggle Controls on Top Right */}
      <div className="absolute top-4 right-4 z-40 hidden md:flex items-center space-x-2 bg-slate-900/90 border border-slate-700/80 px-3 py-1.5 rounded-full shadow-2xl backdrop-blur-md">
        <span className="text-xs text-slate-300 font-medium">Device Frame</span>
        <button
          onClick={onToggleFrame}
          className="p-1 rounded-full text-emerald-400 hover:text-white transition-colors"
          title="Switch to Fullscreen Desktop Mode"
        >
          <Monitor className="w-4 h-4" />
        </button>
      </div>

      {/* Smartphone Chassis Container */}
      <div className="w-full max-w-[440px] h-full md:h-[94vh] md:max-h-[890px] bg-[#0b111a] md:rounded-[44px] md:border-[8px] md:border-[#1e2736] shadow-2xl overflow-hidden flex flex-col relative ring-1 ring-white/10">
        {/* Phone Speaker Notch & Dynamic Status on Mobile Frame */}
        <div className="hidden md:flex w-full bg-[#0b111a] pt-3 pb-1 px-8 items-center justify-between z-30 flex-shrink-0 text-[11px] font-mono text-slate-400 border-b border-surface-container-high/40">
          {/* Time & Carrier */}
          <div className="flex items-center space-x-2">
            <span className="font-bold text-white tracking-tight">{currentTime}</span>
            <span className={`text-[10px] font-sans font-semibold ${
              !isOnline ? 'text-amber-400' : 'text-emerald-400'
            }`}>
              {carrierText}
            </span>
          </div>

          {/* Dynamic Island / Speaker Pill */}
          <div className="w-24 h-4 bg-black rounded-full flex items-center justify-center space-x-2 px-2 shadow-inner">
            <div className="w-2 h-2 rounded-full bg-slate-800" />
            <div className="w-2 h-2 rounded-full bg-emerald-500/80 animate-pulse" />
          </div>

          {/* Battery & Signal */}
          <div className="flex items-center space-x-1.5 text-slate-300">
            {isSat ? (
              <Radio className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
            ) : isOnline ? (
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <WifiOff className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span className="text-[10px] font-mono">{satelliteState?.battery ?? 92}%</span>
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>

        {/* Inner App Content */}
        <div className="flex-1 overflow-hidden flex flex-col relative w-full h-full">
          {children}
        </div>

        {/* Phone Bottom Home Bar Indicator */}
        <div className="hidden md:flex w-full py-2 bg-[#090e15] items-center justify-center flex-shrink-0">
          <div className="w-32 h-1 bg-slate-600 rounded-full" />
        </div>
      </div>
    </div>
  );
};
