import React, { useState } from 'react';
import { Contact } from '../types';
import { sounds } from '../services/soundEffects';

interface CallsViewProps {
  contacts: Contact[];
  onStartVoiceCall: (contact: Contact) => void;
  onStartVideoCall: (contact: Contact) => void;
  onOpenWalkieTalkie: () => void;
  onOpenSos: () => void;
}

export const CallsView: React.FC<CallsViewProps> = ({
  contacts,
  onStartVoiceCall,
  onStartVideoCall,
  onOpenWalkieTalkie,
  onOpenSos
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'missed'>('all');

  const recentCalls = [
    {
      id: 'c1',
      contact: contacts[0] || { name: 'Elena Rostova', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150' },
      type: 'voice',
      direction: 'incoming',
      timestamp: 'Today, 10:14 AM',
      mode: 'satellite',
      status: 'completed',
      duration: '02:45'
    },
    {
      id: 'c2',
      contact: contacts[1] || { name: 'Alpine SAR Ops', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
      type: 'video',
      direction: 'outgoing',
      timestamp: 'Yesterday, 04:30 PM',
      mode: 'internet',
      status: 'completed',
      duration: '08:12'
    },
    {
      id: 'c3',
      contact: contacts[2] || { name: 'Marcus Vance', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150' },
      type: 'voice',
      direction: 'missed',
      timestamp: 'Oct 24, 07:15 PM',
      mode: 'satellite',
      status: 'missed',
      duration: '00:00'
    }
  ];

  const fallbackContact: Contact = contacts[0] || (recentCalls[0]?.contact as any) || {
    id: 'c_default',
    name: 'Elena Rostova',
    role: 'Alpine Research Lead',
    phone: '+1 (555) 0124',
    nexusId: 'NX-ELENA-SAT',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    online: true,
    lastSeen: 'Active now',
    satelliteLinked: true,
    satelliteSignal: 94,
    isGroup: false,
    unreadCount: 0,
    lastMessage: 'Satellite audio channel active',
    lastMessageTime: 'Just now',
    verifiedBharat: true
  };

  return (
    <div className="flex-1 w-full flex flex-col bg-surface select-none overflow-y-auto no-scrollbar">
      {/* Header */}
      <header className="sticky top-0 w-full z-40 pt-safe bg-surface-dim/90 backdrop-blur-xl border-b border-surface-container-high/60 shadow-sm">
        <div className="w-full h-16 px-4 flex items-center justify-between">
          <div className="flex items-center gap-space-sm">
            <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center text-primary shrink-0 shadow-sm">
              <span className="material-symbols-outlined text-[20px]">call</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-headline-sm text-base font-bold tracking-tight text-on-surface">Nexus</span>
                <span className="font-mono text-[9px] px-1.5 py-0.5 rounded bg-primary/10 text-primary font-semibold">
                  CALLS
                </span>
              </div>
              <p className="font-body-sm text-[11px] text-on-surface-variant">Low-Bandwidth Satellite Audio</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenWalkieTalkie}
              className="h-9 px-3 rounded-lg bg-surface-container-high hover:bg-surface-bright text-secondary text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <span className="material-symbols-outlined text-base">radio</span>
              <span>PTT Radio</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full px-4 py-4 space-y-4 pb-8">
        {/* Quick Action Tiles - 2x2 Grid with Identical Heights */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => onStartVoiceCall(fallbackContact)}
            className="p-3.5 h-[110px] rounded-2xl bg-surface-container border border-surface-container-high hover:border-primary/40 text-left transition-all active:scale-[0.98] shadow-sm flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">call</span>
            </div>
            <div>
              <span className="font-semibold text-xs text-on-surface block leading-tight">Voice Call</span>
              <span className="font-mono text-[10px] text-on-surface-variant block mt-0.5">2.4kbps Sat-Codec</span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onStartVideoCall(fallbackContact)}
            className="p-3.5 h-[110px] rounded-2xl bg-surface-container border border-surface-container-high hover:border-secondary/40 text-left transition-all active:scale-[0.98] shadow-sm flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-secondary/15 text-secondary flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">videocam</span>
            </div>
            <div>
              <span className="font-semibold text-xs text-on-surface block leading-tight">Video Link</span>
              <span className="font-mono text-[10px] text-on-surface-variant block mt-0.5">Adaptive Frame Flow</span>
            </div>
          </button>

          <button
            type="button"
            onClick={onOpenWalkieTalkie}
            className="p-3.5 h-[110px] rounded-2xl bg-surface-container border border-surface-container-high hover:border-amber-500/40 text-left transition-all active:scale-[0.98] shadow-sm flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">radio</span>
            </div>
            <div>
              <span className="font-semibold text-xs text-on-surface block leading-tight">Walkie-Talkie</span>
              <span className="font-mono text-[10px] text-on-surface-variant block mt-0.5">Instant PTT Burst</span>
            </div>
          </button>

          <button
            type="button"
            onClick={onOpenSos}
            className="p-3.5 h-[110px] rounded-2xl bg-surface-container border border-surface-container-high hover:border-error/40 text-left transition-all active:scale-[0.98] shadow-sm flex flex-col justify-between"
          >
            <div className="w-10 h-10 rounded-xl bg-error/15 text-error flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">sos</span>
            </div>
            <div>
              <span className="font-semibold text-xs text-on-surface block leading-tight">Distress Beacon</span>
              <span className="font-mono text-[10px] text-error font-medium block mt-0.5">Emergency SAR</span>
            </div>
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-2 border-b border-surface-container-high pb-2">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'all'
                ? 'bg-primary/15 text-primary'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Recent Calls
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('missed')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'missed'
                ? 'bg-error-container text-error'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            Missed
          </button>
        </div>

        {/* Call Log List */}
        <div className="flex flex-col divide-y divide-surface-container-high/60 bg-surface-container rounded-2xl border border-surface-container-high overflow-hidden shadow-md">
          {recentCalls
            .filter((c) => activeTab === 'all' || c.status === 'missed')
            .map((call) => (
              <div key={call.id} className="p-3.5 flex items-center justify-between gap-3 hover:bg-surface-container-high/60 transition-colors">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      alt={call.contact.name}
                      src={call.contact.avatar}
                      className="w-11 h-11 rounded-2xl object-cover ring-1 ring-surface-container-highest"
                    />
                    <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-surface-container-lowest flex items-center justify-center text-primary text-[10px] border border-surface-container-high">
                      <span className="material-symbols-outlined text-[10px]">
                        {call.direction === 'missed' ? 'call_missed' : call.direction === 'incoming' ? 'call_received' : 'call_made'}
                      </span>
                    </span>
                  </div>

                  <div className="flex flex-col min-w-0">
                    <span className="font-semibold text-xs text-on-surface truncate">
                      {call.contact.name}
                    </span>
                    <div className="flex items-center gap-1.5 text-[11px] text-on-surface-variant mt-0.5">
                      <span className="font-mono">{call.timestamp}</span>
                      {call.mode === 'satellite' && (
                        <span className="font-mono text-[9px] px-1 py-0.2 rounded bg-secondary/15 text-secondary">
                          SAT
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playSentSound();
                      onStartVoiceCall(call.contact as any);
                    }}
                    className="w-9 h-9 rounded-xl bg-surface-container-high hover:bg-surface-bright flex items-center justify-center text-primary active:scale-95 transition-all"
                  >
                    <span className="material-symbols-outlined text-lg">call</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      sounds.playSentSound();
                      onStartVideoCall(call.contact as any);
                    }}
                    className="w-9 h-9 rounded-xl bg-surface-container-high hover:bg-surface-bright flex items-center justify-center text-secondary active:scale-95 transition-all"
                  >
                    <span className="material-symbols-outlined text-lg">videocam</span>
                  </button>
                </div>
              </div>
            ))}
        </div>
      </main>
    </div>
  );
};
